# AP Coolcare Services website

Static website for AP Coolcare Services, the HVAC arm of
[AP Aluminum and Glass](https://apaluminumandglass.com/). Plain HTML, CSS and
JavaScript: no build step, no dependencies.

## Folder layout

```
index.html              Page markup (home page; product and project pages are rendered by main.js)
404.html                Shown by GitHub Pages for unknown addresses
.nojekyll               Tells GitHub Pages to serve files as-is
assets/
  css/styles.css        All styles
  js/main.js            Navigation, product and project data, photo viewer, booking form
  img/                  Photos and logo (WebP)
```

## Editing content

- **Products** (categories, series, models, capacities, features): edit the
  `PRODUCTS` list and the "Additional lineups" section in `assets/js/main.js`.
  Prices are intentionally not listed.
- **Projects**: edit the `PROJECTS` list in `assets/js/main.js`.
- **Photos**: add a `.webp`, `.jpg` or `.png` file to `assets/img/`, then point
  to it from `index.html` or from the `IMG` list in `assets/js/main.js`.
- **Home page text, pricing, FAQ, contact details**: edit `index.html`.

## Upload to GitHub (no Git needed)

1. Sign in at [github.com](https://github.com) and click **New repository**.
   Name it, for example, `ap-coolcare-website`, set it to **Public**, and create it.
2. On the new repository page, click **uploading an existing file**.
3. Drag in **everything inside this folder** (`index.html`, `404.html`,
   `.nojekyll`, `README.md` and the `assets` folder). Keep the folder structure.
   Windows hides files starting with a dot, so if `.nojekyll` does not show,
   it is optional for this site.
4. Click **Commit changes**.

## Publish with GitHub Pages

1. In the repository, open **Settings → Pages**.
2. Under **Build and deployment**, choose **Deploy from a branch**, branch
   **main**, folder **/ (root)**, and save.
3. After a minute the site is live at
   `https://<your-github-username>.github.io/ap-coolcare-website/`.

To use your own domain (for example `www.apcoolcare.com`), add it under
**Settings → Pages → Custom domain** and follow GitHub's DNS instructions.

## Preview locally

Open `index.html` in a browser. Everything works from the file, including the
Products and Projects pages.

## Before going live

- **Booking form**: it only shows a confirmation on screen and does not send
  anything yet. Connect it to a form service (for example Formspree or
  Netlify Forms) or your email system so requests reach
  apcoolcare.support@gmail.com.
- **Testimonials** were removed. Add real client reviews later if you want them back.
- **Share preview image**: social sites need an absolute address. Once the site
  is live, change `og:image` in `index.html` to the full URL, for example
  `https://<your-site>/assets/img/hero-technicians.webp`.
