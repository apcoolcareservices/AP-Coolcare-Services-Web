(function () {
  var header = document.querySelector('.site-header');
  var menuBtn = document.getElementById('menuBtn');
  function onScroll() { header.classList.toggle('scrolled', window.scrollY > 8); }
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  menuBtn.addEventListener('click', function () {
    var open = header.classList.toggle('open');
    menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    menuBtn.textContent = open ? 'Close' : 'Menu';
  });
  document.querySelectorAll('.nav a').forEach(function (a) {
    a.addEventListener('click', function () { header.classList.remove('open'); menuBtn.setAttribute('aria-expanded', 'false'); menuBtn.textContent = 'Menu'; });
  });

  // Active nav link
  var links = Array.prototype.slice.call(document.querySelectorAll('.nav a'));
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if ('IntersectionObserver' in window) {
    var secObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) links.forEach(function (l) { l.classList.toggle('active', l.getAttribute('href') === '#' + e.target.id); });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    ['services', 'about', 'pricing', 'testimonials', 'faq', 'contact'].forEach(function (id) { var el = document.getElementById(id); if (el) secObs.observe(el); });

    // Reveal: elements below the fold slide up into place. Opacity never changes.
    if (!reduce) {
      var revObs = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.remove('pre'); revObs.unobserve(e.target); } });
      }, { rootMargin: '0px 0px -8% 0px' });
      document.querySelectorAll('.reveal').forEach(function (el, i) {
        if (el.getBoundingClientRect().top > window.innerHeight) {
          el.classList.add('pre');
          el.style.transitionDelay = ((i % 3) * 80) + 'ms';
          revObs.observe(el);
        }
      });
    }
  }


  // ---------- Project pages (hash routes: #projects, #project-<slug>) ----------
  var IMG = {
    pp_window: 'assets/img/pp-window.webp',
    pp_wall: 'assets/img/pp-wall.webp',
    pp_cassette: 'assets/img/pp-cassette.webp',
    pp_floor: 'assets/img/pp-floor.webp',
    p_chilled: 'assets/img/p-chilled.webp',
    floorunit: 'assets/img/floorunit.webp',
    wallclean: 'assets/img/wallclean.webp',
    rooftop: 'assets/img/rooftop.webp',
    crew: 'assets/img/hero-technicians.webp',
    team: 'assets/img/team.webp',
    building: 'assets/img/building.webp',
    service: 'assets/img/about-pms-teamquest.webp',
    towers: 'assets/img/towers.webp',
    indoor: 'assets/img/indoor.webp',
    install: 'assets/img/about-ridgewood-install.webp',
    boxes: 'assets/img/boxes.webp',
    survey: 'assets/img/about-filfresh-survey.webp'
  };
  var PROJECTS = [
    { slug: 'teamquest', client: 'TeamQuest Technology Inc.', short: 'TeamQuest Technology', type: 'Maintenance', also: 'Installation', tag: 'Maintenance + Installation',
      headline: 'Preventive maintenance for 162 units, plus 4 new 5TR units', units: '162', unitsLabel: 'units maintained',
      service: 'Preventive Maintenance Services (PMS) and Air Conditioning Installation',
      summary: 'Our largest contract to date: preventive maintenance across 162 aircon units for TeamQuest Technology, plus installation of four 5TR units.',
      installs: [['2 units', '5TR Ceiling Cassette'], ['2 units', '5TR Floor Standing']],
      body: 'We keep 162 units running efficiently through scheduled preventive maintenance, catching small faults before they become breakdowns. On the same site we installed four 5TR (5-ton refrigeration) units: two ceiling cassettes and two floor-standing units.',
      scope: ['Preventive maintenance of 162 units: filter, coil, drain and electrical checks', 'Refrigerant level checks and performance testing', 'Installation of 2 × 5TR Ceiling Cassette units', 'Installation of 2 × 5TR Floor Standing units'],
      photos: [['building', 'TeamQuest Technology facility'], ['rooftop', 'Rooftop cleaning of an outdoor unit grille, harnessed to a lifeline'], ['service', 'Technician servicing a Koppel outdoor unit in full safety harness'], ['floorunit', 'Servicing a floor-standing unit indoors'], ['wallclean', 'Wall-mounted unit cleaning with a drain bag to keep the office dry']] },
    { slug: 'kongkreto', client: 'Kongkreto Pilipinas Inc.', short: 'Kongkreto Pilipinas', type: 'Maintenance',
      headline: 'Preventive maintenance for 4 office units', units: '4', unitsLabel: 'units maintained',
      service: 'Preventive Maintenance Services (PMS)',
      summary: 'Aircon preventive maintenance for Kongkreto Pilipinas, keeping their workspace units clean and efficient.',
      body: 'A focused maintenance visit: our crew serviced each unit on site, working around the team so the office kept running.',
      scope: ['Filter cleaning and coil inspection', 'Refrigerant level check', 'Drain line cleaning', 'Performance testing'],
      photos: [['crew', 'Two technicians servicing a wall-mounted unit'], ['team', 'AP Coolcare crew with the Kongkreto Pilipinas team']] },
    { slug: 'ridgewood', client: 'Ridgewood Tower', short: 'Ridgewood Tower', type: 'Installation',
      headline: 'Dismantling and installation of units', units: 'High-rise', unitsLabel: 'residential tower',
      service: 'Air Conditioning Installation',
      summary: 'Dismantling existing units and installing new ones at Ridgewood Tower, a high-rise residential building.',
      body: 'High-rise work needs careful handling: old units are taken down safely, new units are mounted, piped and test-run before handover.',
      scope: ['Safe dismantling of existing units', 'Mounting of indoor and outdoor units', 'Piping and electrical connection', 'Test run and handover'],
      photos: [['towers', 'Ridgewood Tower'], ['indoor', 'Newly installed indoor unit'], ['install', 'Outdoor condensing unit after installation']] },
    { slug: 'filfresh', client: 'Fil-Fresh Inc.', short: 'Fil-Fresh', type: 'Installation',
      headline: 'Survey, supply and installation', units: 'End-to-end', unitsLabel: 'survey to install',
      service: 'HVAC Consultation & Site Assessment',
      summary: 'From site survey to supply and installation of new units for Fil-Fresh, handled by one team.',
      body: 'We surveyed the site to plan unit placement, supplied the equipment, and installed it. One partner from assessment to commissioning.',
      scope: ['Site survey and unit placement planning', 'Supply of new aircon units', 'Installation and commissioning'],
      photos: [['survey', 'Site survey of the building exterior'], ['boxes', 'New LG units delivered to site'], ['install', 'Installed outdoor unit']] }
  ];

  // ---------- Products (hash routes: #products, #product-<slug>) ----------
  var ART = {
    window: '<svg viewBox="0 0 240 150" aria-hidden="true"><rect class="art-soft" x="20" y="14" width="200" height="122" rx="4"/><rect class="art-fill" x="48" y="34" width="144" height="86" rx="8"/><rect class="art-line" x="62" y="48" width="78" height="56" rx="4"/><path class="art-line" d="M62 60h78M62 72h78M62 84h78M62 96h78"/><circle class="art-dot" cx="170" cy="56" r="4"/><path class="art-red" d="M156 76h22M156 88h22"/><path class="art-air" d="M70 128c10 8 30 8 40 0M120 128c10 8 30 8 40 0"/></svg>',
    wall: '<svg viewBox="0 0 240 150" aria-hidden="true"><path class="art-soft" d="M20 20h200"/><rect class="art-fill" x="30" y="36" width="180" height="54" rx="18"/><path class="art-line" d="M44 76h152"/><path class="art-line" d="M52 84h136"/><circle class="art-dot" cx="190" cy="52" r="3.5"/><path class="art-air" d="M60 104c20 14 40 14 60 0M120 104c20 14 40 14 60 0M80 122c14 10 28 10 42 0"/></svg>',
    floor: '<svg viewBox="0 0 240 150" aria-hidden="true"><path class="art-soft" d="M30 140h180"/><rect class="art-fill" x="92" y="10" width="56" height="130" rx="10"/><rect class="art-line" x="102" y="20" width="36" height="26" rx="3"/><path class="art-line" d="M102 28h36M102 36h36"/><rect class="art-line" x="104" y="96" width="32" height="34" rx="3"/><circle class="art-dot" cx="120" cy="60" r="3.5"/><path class="art-red" d="M110 70h20"/><path class="art-air" d="M150 28c18 4 32 12 44 24M150 40c14 4 26 10 36 20"/></svg>',
    cassette: '<svg viewBox="0 0 240 150" aria-hidden="true"><path class="art-line" d="M14 30h212"/><path class="art-soft" d="M14 22h212"/><rect class="art-fill" x="70" y="30" width="100" height="22" rx="4"/><path class="art-line" d="M80 46h80"/><rect class="art-red" x="100" y="36" width="40" height="8" rx="2"/><path class="art-air" d="M72 60c-10 20-24 34-40 42M168 60c10 20 24 34 40 42M104 62c-2 22-6 40-12 56M136 62c2 22 6 40 12 56"/></svg>',
    concealed: '<svg viewBox="0 0 240 150" aria-hidden="true"><rect class="art-soft" x="40" y="14" width="160" height="40" rx="6"/><path class="art-line" d="M14 62h212"/><path class="art-line" d="M60 34h120"/><rect class="art-fill" x="86" y="22" width="68" height="24" rx="4"/><path class="art-line" d="M154 34h36v28M86 34H50v28"/><rect class="art-red" x="36" y="62" width="28" height="6" rx="2"/><rect class="art-red" x="176" y="62" width="28" height="6" rx="2"/><path class="art-air" d="M50 76c-4 16-10 28-18 38M190 76c4 16 10 28 18 38M50 76c4 18 4 32 0 46M190 76c-4 18-4 32 0 46"/></svg>',
    chilled: '<svg viewBox="0 0 240 150" aria-hidden="true"><path class="art-soft" d="M14 138h212"/><rect class="art-fill" x="24" y="52" width="192" height="80" rx="8"/><circle class="art-line" cx="64" cy="52" r="18"/><circle class="art-line" cx="120" cy="52" r="18"/><circle class="art-line" cx="176" cy="52" r="18"/><path class="art-line" d="M64 40v24M52 52h24M120 40v24M108 52h24M176 40v24M164 52h24"/><path class="art-line" d="M40 84h160M40 100h160M40 116h160"/><path class="art-red" d="M216 92h14M216 112h14"/><circle class="art-dot" cx="196" cy="70" r="3.5"/></svg>'
  };
  var PRODUCTS = [
    { slug: 'window', name: 'Window Type', short: 'Window Type', seg: ['Residential'], cap: '0.8 – 2.5 HP', rate: '₱1,000', photo: 'pp_window', shot: true, photoAlt: 'Window-type aircon unit',
      tagline: 'Simple, compact cooling for single rooms.',
      intro: 'One self-contained unit that fits a wall or window opening. The easiest to install and the most affordable to run and maintain.',
      good: ['Bedrooms and small rooms', 'Rentals and quick replacements', 'Spaces without room for an outdoor unit'],
      series: [
        { brand: 'LG', name: 'DUALCOOL Window Type, Standard', model: 'LA080GC2 – LA250GC2', cap: '0.8 – 2.5 HP', feats: ['Dual Inverter compressor', 'ThinQ Wi-Fi', '10-yr compressor warranty'] },
        { brand: 'Koppel', name: 'Full DC Inverter, Compact', model: '', cap: '1.0 – 2.5 HP', feats: ['R32 refrigerant', 'Gold fins', 'Up to 60% energy savings'] },
        { brand: 'Koppel', name: 'Aera Series', model: '', cap: 'Various', feats: ['Gold fins', 'Energy saver mode', '24-hr timer', 'Sleep mode'] }
      ] },
    { slug: 'wall', name: 'Wall Mounted Split', short: 'Wall Mounted', seg: ['Residential', 'Small business'], cap: '1.0 – 2.5 HP', rate: '₱1,500', photo: 'pp_wall', shot: true, photoAlt: 'Wall-mounted split indoor unit',
      tagline: 'Quiet, efficient cooling with a slim indoor unit.',
      intro: 'A slim indoor unit on the wall, connected to an outdoor unit. Quieter inside and more efficient than window types, with smart and air-purifying options.',
      good: ['Bedrooms, living rooms and home offices', 'Small offices, clinics and shops', 'Anyone who wants low noise and inverter savings'],
      series: [
        { brand: 'LG', name: 'DUALCOOL Standard', model: 'HS09ISY3 – HS24ISY2', cap: '1.0 – 2.5 HP', feats: ['Freeze Cleaning', 'ThinQ Wi-Fi', 'Energy Saving'] },
        { brand: 'LG', name: 'DUALCOOL Standard (B-series)', model: 'HS09ISB – HS24ISB', cap: '1.0 – 2.5 HP', feats: ['Active Energy Control', 'Fast Cooling', 'Low Noise'] },
        { brand: 'LG', name: 'DUALCOOL Premium, AI Air', model: 'HS09IPX3 – HS24IPX3', cap: '1.0 – 2.5 HP', feats: ['DUALCOOL AI Air', 'Plasmaster Ionizer++'] },
        { brand: 'LG', name: 'DUALCOOL Deluxe, AI Air', model: 'HS09APX3 – HS24APX3', cap: '1.0 – 2.5 HP', feats: ['Human Detecting Sensor', 'All Cleaning'] },
        { brand: 'Koppel', name: 'Super Inverter DC PRO Plus', model: '', cap: 'Up to 60%', capNote: 'energy savings', feats: ['Super Ionizer', 'ECO Plus AI', '4D Airflow', 'Self diagnosis'] },
        { brand: 'LG', name: 'Multi Split, Smart Inverter', model: '', cap: 'Up to 5', capNote: 'indoor units', feats: ['One outdoor unit for multiple rooms'] },
        { brand: 'Koppel', name: 'Multi Split, Super iMatch Full DC', model: '', cap: 'Up to 5', capNote: 'indoor units', feats: ['Saves outdoor space', 'Single outdoor unit, multiple zones'] }
      ] },
    { slug: 'floor', name: 'Floor Mounted', short: 'Floor Mounted', seg: ['Residential', 'Commercial'], cap: '4.0 – 6.0 HP', rate: '₱2,000', photo: 'pp_floor', shot: true, photoAlt: 'Floor-standing indoor unit with its outdoor unit',
      tagline: 'High-capacity cooling for large open spaces.',
      intro: 'A tall standing unit that throws air across big rooms without ceiling work. Ideal where you need a lot of cooling fast.',
      good: ['Large living areas and function rooms', 'Showrooms, restaurants and halls', 'Offices without ceiling space for cassettes'],
      series: [
        { brand: 'LG', name: 'Floor Standing, Entry', model: 'ZPNQ36GT3E0, ZPNQ60GT3A0', cap: '4.0 – 6.0 HP', feats: ['Single commercial line'] },
        { brand: 'LG', name: 'Floor Standing, Standard', model: 'ZPNQ36GR5A0, ZPNQ48GT3A0, APNQ60GT3E4', cap: '4.0 – 6.0 HP', feats: ['Single commercial line'] },
        { brand: 'Koppel', name: 'Super Inverter', model: '', cap: 'Up to 50%', capNote: 'energy savings', feats: ['R32 refrigerant', 'Auto swing', 'LCD display', 'Sleep mode'] },
        { brand: 'Koppel', name: 'Era Series (R410A)', model: '', cap: 'Heavy duty', feats: ['Highly efficient compressor', 'Anti-rust', '24-hr timer'] }
      ] },
    { slug: 'cassette', name: 'Ceiling Cassette', short: 'Ceiling Cassette', seg: ['Commercial'], cap: '1.5 – 6.0 HP', rate: '₱2,500', photo: 'pp_cassette', shot: true, photoAlt: 'Four-way ceiling cassette unit',
      tagline: 'Even airflow from the ceiling, out of the way.',
      intro: 'Installed flush in the ceiling with air flowing out on one, four or all sides. Clean looks and even cooling across the room.',
      good: ['Offices and meeting rooms', 'Retail stores and restaurants', 'Rooms where wall space is limited'],
      series: [
        { brand: 'LG', name: 'Ceiling Cassette 1-Way, Standard', model: 'ZTNQ12GULA0 – ZTNQ24GTLA0', cap: '1.5 – 2.5 HP', feats: ['Slim one-way airflow'] },
        { brand: 'LG', name: 'Ceiling Cassette 4-Way, Entry', model: 'ZTNQ18GPLE0 – ZTNQ60GMLA0', cap: '2.0 – 6.0 HP', feats: ['Four-way airflow'] },
        { brand: 'LG', name: 'Ceiling Cassette 4-Way, Standard', model: 'ZTNQ18GPLA0 – ZTNQ48GMLA0', cap: '2.0 – 5.0 HP', feats: ['Four-way airflow'] },
        { brand: 'LG', name: 'Round Cassette, Standard', model: 'ZTNQ36GYLA0, ZTNQ48GYLA0', cap: '4.0 – 5.0 HP', feats: ['360° round airflow'] },
        { brand: 'Koppel', name: 'Ceiling Cassette Inverter, Super Inverter', model: '', cap: 'Up to 50%', capNote: 'energy savings', feats: ['R32 refrigerant', '360° airflow', 'Quiet design', 'Lock function'] }
      ] },
    { slug: 'concealed', name: 'Ceiling Concealed', short: 'Ceiling Concealed', seg: ['Commercial'], cap: '2.0 – 6.0 HP', capAlt: 'Ducted up to 10 TR', rate: '₱3,000', photo: 'hd_concealed', shot: true, photoAlt: 'Ceiling-mounted indoor unit with a slim linear grille',
      tagline: 'Hidden above the ceiling, only grilles in view.',
      intro: 'The unit sits above the ceiling and delivers air through ducts and grilles. The cleanest look, and one unit can serve several rooms.',
      good: ['Premium homes and condos', 'Offices, lobbies and hotels', 'Fit-outs where design matters'],
      series: [
        { brand: 'LG', name: 'Ceiling Concealed Duct, Low Static', model: 'ZBNQ18GL2A0, ZBNQ24GL3A0', cap: '2.0 – 2.5 HP', feats: ['Short duct runs'] },
        { brand: 'LG', name: 'Ceiling Concealed Duct, Mid / High Static', model: 'ZBNQ18GM1A0 series', cap: '2.0 – 6.0 HP', feats: ['Longer duct runs, multiple grilles'] },
        { brand: 'Koppel', name: 'Ceiling Concealed Inverter, Super Inverter', model: '', cap: 'Up to 50%', capNote: 'energy savings', feats: ['Wired controller', 'High-density filter', 'Independent dehumidification'] },
        { brand: 'Koppel', name: 'Vertical / Horizontal Split Ducted (R410A)', model: '', cap: '3.0 – 10.0 TR', feats: ['Heavy-duty fan motor', 'Anti-rust', 'Highly efficient'] }
      ] },
    { slug: 'chilled', name: 'Chilled Water Systems', short: 'Chilled Water', seg: ['Industrial', 'Commercial'], cap: '30 kW – 3,000 TR', rate: 'Quote', photo: 'p_chilled', photoAlt: 'Rooftop central cooling equipment with insulated piping',
      tagline: 'Central plant cooling for buildings and facilities.',
      intro: 'Chillers cool water that is pumped to air handling units around the building. The standard for malls, hospitals, factories and large commercial buildings.',
      good: ['Large commercial buildings and malls', 'Factories and industrial plants', 'Hospitals, data rooms and campuses'],
      series: [
        { brand: 'Koppel', name: 'Air-Cooled Modular Scroll Chiller', model: '', cap: '30 – 250 kW', feats: ['Digital scroll technology', '10–100% step-less capacity'] },
        { brand: 'Koppel', name: 'Air-Cooled Modular Screw Chiller', model: '', cap: '107 – 500 TR', feats: ['R134a refrigerant', 'Lowest total cost of ownership'] },
        { brand: 'Koppel', name: 'Water-Cooled Screw Chiller', model: '', cap: '95 – 500 TR', feats: ['Twin-rotor screw compressor', 'Built-in oil separator'] },
        { brand: 'Koppel', name: 'Water-Cooled Centrifugal Chiller', model: '', cap: '500 – 3,000 TR', feats: ['Two-stage compression', 'Free cooling technology'] },
        { brand: 'Koppel', name: 'Water-Cooled Magnetic Centrifugal Chiller', model: '', cap: '170 – 1,800 TR', feats: ['Oil-free design', 'Motor efficiency up to 97%'] },
        { brand: 'Koppel', name: 'Water-Cooled Inverter Direct-Drive Centrifugal', model: '', cap: '250 – 1,300 TR', feats: ['Two-stage compression', 'Anti-surge technology'] },
        { brand: 'Koppel', name: 'Air Handling Units (Horizontal / Vertical / Modular)', model: '', cap: 'Custom', capNote: 'configured', feats: ['Built to project airflow and space requirements'] }
      ] }
  ];
  // ---------- Additional lineups: Everest (2026 2H) and Concepcion-Carrier (Sept 2026) ----------
  // Models, capacities and features only. Prices are intentionally left out.
  ART.suspended = '<svg viewBox="0 0 240 150" aria-hidden="true"><path class="art-line" d="M14 22h212"/><path class="art-soft" d="M14 14h212"/><path class="art-line" d="M60 22v10M180 22v10"/><rect class="art-fill" x="40" y="32" width="160" height="40" rx="10"/><path class="art-line" d="M54 62h132"/><circle class="art-dot" cx="182" cy="44" r="3.5"/><path class="art-red" d="M150 44h20"/><path class="art-air" d="M60 84c14 14 34 22 60 22s46-8 60-22M80 104c12 8 26 12 40 12s28-4 40-12"/></svg>';
  ART.aircare = '<svg viewBox="0 0 240 150" aria-hidden="true"><path class="art-soft" d="M30 140h180"/><rect class="art-fill" x="88" y="18" width="64" height="122" rx="14"/><circle class="art-line" cx="120" cy="56" r="20"/><circle class="art-line" cx="120" cy="56" r="10"/><path class="art-line" d="M100 92h40M100 104h40M100 116h40"/><circle class="art-dot" cx="120" cy="30" r="3.5"/><path class="art-air" d="M160 40c16 2 28 8 38 18M160 60c12 2 22 6 30 14M80 40c-16 2-28 8-38 18M80 60c-12 2-22 6-30 14"/></svg>';

  function addSeries(slug, list) {
    var p = PRODUCTS.filter(function (x) { return x.slug === slug; })[0];
    if (p) p.series = p.series.concat(list);
  }

  addSeries('window', [
    { brand: 'Carrier', name: 'Optima Green, Non-Inverter', model: 'WCART006EC, WCARZ008EC1, WCART010EC', cap: '0.5 – 1.0 HP', feats: ['Non-inverter', 'Window type'] },
    { brand: 'Carrier', name: 'Aura Top Discharge, Non-Inverter', model: 'WCARK008EE, WCART010EE', cap: '0.75 – 1.0 HP', feats: ['Non-inverter', 'Top air discharge'] },
    { brand: 'Carrier', name: 'Aura Side Discharge, Non-Inverter', model: 'WCARJ008EE, WCARJ010EE, WCARS014EE', cap: '0.75 – 1.5 HP', feats: ['Non-inverter', 'Side air discharge', 'Remote control (0.75 – 1.0 HP)'] },
    { brand: 'Carrier', name: 'Aura Plus, Non-Inverter', model: 'WCARK006EECG, WCARJ010EEC3', cap: '0.5 – 1.0 HP', feats: ['Non-inverter', 'Remote control'] },
    { brand: 'Carrier', name: 'Compact Inverter', model: 'WCARH008EEVC2', cap: '0.75 HP', feats: ['Inverter', 'Remote control', 'Compact body'] },
    { brand: 'Carrier', name: 'Optima Inverter', model: 'WCART006EEV, WCART009EEV, WCART012EEV', cap: '0.5 – 1.5 HP', feats: ['Inverter', 'Remote control'] },
    { brand: 'Carrier', name: 'Aura Inverter, Side Discharge', model: 'WCARJ009EEV', cap: '1.0 HP', feats: ['Inverter', 'Side air discharge', 'Remote control'] },
    { brand: 'Carrier', name: 'Aura Inverter, Top Discharge', model: 'WCAR012VU-W1, 51CTD018308, 53CTD024308', cap: '1.5 – 2.5 HP', feats: ['Inverter', 'Top air discharge', 'Remote control'] },
    { brand: 'Carrier', name: 'Neo Veza Inverter', model: 'WCAR009VV-W', cap: '1.25 HP', feats: ['Inverter'] },
    { brand: 'Condura', name: 'Duracore, Non-Inverter', model: 'WCONT006EC, WCONZ008EC1, WCONT010EC', cap: '0.5 – 1.0 HP', feats: ['Non-inverter'] },
    { brand: 'Condura', name: '6X Series, Non-Inverter', model: 'WCONH008EC2, WCONH010EC2, WCONH014EC1', cap: '0.75 – 1.5 HP', feats: ['Non-inverter', 'Deluxe 6X Series HE'] },
    { brand: 'Condura', name: '6X Plus, Non-Inverter', model: 'WCONH010EE1', cap: '1.0 HP', feats: ['Non-inverter', 'Remote control', 'S-Grille+'] },
    { brand: 'Condura', name: 'Compact Inverter', model: 'WCONH008EEVC2, WCONH009EEVC2', cap: '0.75 – 1.0 HP', feats: ['Inverter', 'Remote control', 'Compact body'] },
    { brand: 'Condura', name: 'Primea Inverter', model: 'WCON012VU-W1', cap: '1.5 HP', feats: ['Inverter', 'Remote control'] },
    { brand: 'Condura', name: 'Standard Inverter', model: 'WCONH009EEV1, WCONH019EEV', cap: '1.0 – 2.0 HP', feats: ['Inverter', 'Remote control'] },
    { brand: 'Everest', name: 'Window Type Full DC Inverter', model: 'ETIV10CFWTD, ETIV15CFWTD, ETIV20CFWD/G, ETIV25FWD/G', cap: '1.0 – 2.5 HP', feats: ['Full DC inverter', '220V / 1-phase'] },
    { brand: 'Everest', name: 'Window Type Full DC Inverter, Endura', model: 'ETIV08CFWEDA, ETIV10CFWEDA, ETIV15CFWEDA', cap: '0.8 – 1.5 HP', feats: ['Full DC inverter', 'Endura series', '220V / 1-phase'] },
    { brand: 'Everest', name: 'Window Type, Non-Inverter with Remote', model: 'ETA07WDR3-HF, ETA10WTDR3', cap: '0.7 – 1.0 HP', feats: ['Non-inverter', 'Remote control', '220V / 1-phase'] },
    { brand: 'Everest', name: 'Window Type, Non-Inverter Manual', model: 'ETM06WTDR3-HF, ETM10WDR3-HF', cap: '0.6 – 1.0 HP', feats: ['Non-inverter', 'Manual controls', '220V / 1-phase'] },
    { brand: 'Everest', name: 'Portable Aircon, Non-Inverter', model: 'ET10CPOR3, ET15CPOR3', cap: '1.0 – 1.5 HP', feats: ['Portable, no installation', 'Non-inverter', '220V / 1-phase'] }
  ]);

  addSeries('wall', [
    { brand: 'Carrier', name: 'Optima Inverter', model: '53CAC009308-1 – 53CAC024308-1', cap: '1.0 – 2.5 HP', feats: ['Inverter', 'High wall split'] },
    { brand: 'Carrier', name: 'Optima Inverter, 3.0 HP', model: '53CXV030308-1', cap: '3.0 HP', feats: ['Inverter', 'High wall split'] },
    { brand: 'Carrier', name: 'Aura Inverter', model: '53CEP009308-1 – 53CEP024308-1', cap: '1.0 – 2.5 HP', feats: ['Inverter', 'High wall split'] },
    { brand: 'Carrier', name: 'Neo Inverter', model: '53GCVPH010-303P – 53GCVPH018-303P', cap: '1.0 – 2.0 HP', feats: ['Inverter', 'R32 refrigerant'] },
    { brand: 'Carrier', name: 'FlexiSplit Inverter', model: 'CVA-FPV 2.0, CVA-FPV 2.5', cap: '2.0 – 2.5 HP', feats: ['Inverter', 'Wall, ceiling or ducted mounting', 'Mounting kits available'] },
    { brand: 'Carrier', name: 'Stealth Inverter', model: '53CVA-MFV, 53CVA-JCV, 53CVA-TRT (01.5H – 02.5H)', cap: '1.5 – 2.5 HP', feats: ['Inverter', 'Top or side discharge', 'Left- or right-hand piping'] },
    { brand: 'Carrier', name: 'Flexi Stealth Inverter (New)', model: '53NFS012VS – 53NFS024VS (RH / LH)', cap: '1.5 – 2.5 HP', feats: ['Inverter', 'Left- or right-hand piping'] },
    { brand: 'Condura', name: 'Inverter (KPV)', model: '53KPV009313 – 53KPV024313', cap: '1.0 – 2.5 HP', feats: ['Inverter', 'High wall split'] },
    { brand: 'Everest', name: 'Wall Mounted Full DC Inverter', model: 'ETIV10SDCR3 – ETIV30SDCR3', cap: '1.0 – 3.0 HP', feats: ['Full DC inverter', '220V / 1-phase'] },
    { brand: 'Everest', name: 'Wall Mounted Full DC Inverter, Feather', model: 'ETIV10F4DCR3 – ETIV25F4DCR3', cap: '1.0 – 2.5 HP', feats: ['Full DC inverter', 'Feather series', '230V / 1-phase'] }
  ]);

  addSeries('floor', [
    { brand: 'Carrier', name: 'Optima Floor-Mounted', model: '53DFE-ASD04H-1, 53DFE-ASD06H-1', cap: '4.0 – 6.0 HP', feats: ['Remote control', 'Inverter (6.0 HP)'] },
    { brand: 'Carrier', name: 'Floor-Mounted Free-Blow', model: 'SLA AR-HOP 7.5T, FP-53HTA120-5', cap: '7.5 – 10 TR', feats: ['Free-blow discharge', 'Slimpac (10 TR)'] },
    { brand: 'Condura', name: 'Floor-Mounted Inverter', model: '53KFV036313', cap: '4.0 HP', feats: ['Inverter', 'Remote control'] },
    { brand: 'Everest', name: 'Floor Standing Inverter', model: 'ETIV36XFSR3, ETIV601XFSR3, ETIV603XFSR3', cap: '3.0 – 5.0 TR', feats: ['Inverter', '1-phase or 3-phase (5 TR)'] },
    { brand: 'Everest', name: 'Floor Standing, Non-Inverter', model: 'ET36XFS/M', cap: '3.0 TR', feats: ['Non-inverter', '220V / 1-phase'] }
  ]);

  addSeries('cassette', [
    { brand: 'Carrier', name: 'Optima Cassette', model: '53CCG-1-ASC 06.0HP, 53CAV036308-3, 53CAV055308-3', cap: '4.0 – 6.0 HP', feats: ['Four-way cassette', 'R32 refrigerant (53CAV)'] },
    { brand: 'Carrier', name: 'One-Way Cassette Inverter', model: '53CSWC012308, 53CSWC024308', cap: '1.5 – 2.5 HP', feats: ['Inverter', 'One-way airflow'] },
    { brand: 'Carrier', name: 'Hydronic Cassette (Chilled Water)', model: '40HK025-3, 40HK036-3, 40HK044-3', cap: '2 – 4 TR', feats: ['Chilled water fan coil', 'For central plant systems'] },
    { brand: 'Everest', name: 'Ceiling Cassette Inverter', model: 'ETIV36XCCR3, ETIV601XCCR3, ETIV603XCCR3', cap: '3.0 – 5.0 TR', feats: ['Inverter', '1-phase or 3-phase (5 TR)'] },
    { brand: 'Everest', name: 'Ceiling Cassette, Non-Inverter', model: 'ET36XCC/M, ETR2CC60U', cap: '3.0 – 5.0 TR', feats: ['Non-inverter', '1-phase (3 TR) or 3-phase (5 TR)'] }
  ]);

  addSeries('concealed', [
    { brand: 'Carrier', name: 'A7 Ducted Inverter', model: '53CDV012308-4 – 53CDV036308-4', cap: '1.5 – 4.0 HP', feats: ['Inverter', 'Ceiling ducted'] },
    { brand: 'Carrier', name: 'Optima Ducted', model: '53AX-ASC04 / 06, 53AXV-ASD 040 / 060', cap: '4.0 – 6.0 HP', feats: ['Inverter (53AXV) or non-inverter (53AX)', 'With or without supply plenum'] },
    { brand: 'Carrier', name: 'Ceiling Ducted, 7.5 & 10 TR', model: 'AX-HOP 7.5T, AX-HOP 10T', cap: '7.5 – 10 TR', feats: ['Ceiling ducted', '230V'] },
    { brand: 'Carrier', name: 'Ducted Splits, 7.5 & 10 TR', model: '53RUA008, 53RUA012, 53RUA-HOP', cap: '7.5 – 10 TR', feats: ['Ducted split sets'] },
    { brand: 'Carrier', name: 'Ducted Splits, 15 & 20 TR (Dual Condensing)', model: '53RUA016 / 53RUA024 (SDF / HSF)', cap: '15 – 20 TR', feats: ['R-410A refrigerant', 'Dual condensing units', '230V, 380V or 460V'] },
    { brand: 'Carrier', name: 'Gemini Ducted Splits 1:1, 15 & 20 TR', model: '53RUA016 / 53RUA024 (SDF / HSF)-1', cap: '15 – 20 TR', feats: ['R-410A refrigerant', '1:1 condensing unit', '230V, 380V or 460V'] },
    { brand: 'Carrier', name: 'Large Capacity Ducted Splits (Fan Coil)', model: '40AX, 42SLA, 40HTA series', cap: '7.5 – 10 TR', feats: ['R-410A refrigerant', 'Manual or digital controls'] },
    { brand: 'Carrier', name: 'Large Capacity Condensing Units (CDU)', model: '38HOP007 / 012, 38AUD016 / 025', cap: '7.5 – 20 TR', feats: ['R-410A refrigerant', '230V, 380V or 460V'] },
    { brand: 'Carrier', name: 'Large Capacity Air Handling Units (DX)', model: '40RUA008 – 40RUA025, 40RUX034', cap: '7.5 – 30 TR', feats: ['R-410A refrigerant', 'Floor or ceiling mounted'] },
    { brand: 'Carrier', name: 'Large Packaged Ducted Splits', model: '40RUX_38HOP', cap: '30 TR', feats: ['Packaged ducted split', '230V, 380V or 460V'] },
    { brand: 'Everest', name: 'Ceiling Ducted Inverter', model: 'ETIV36DU, ETIV601DU/M', cap: '3.0 – 5.0 TR', feats: ['Inverter', '220V / 1-phase'] }
  ]);

  addSeries('chilled', [
    { brand: 'Carrier', name: 'Chilled Water Air Handling Units', model: '40RMS008 – 40RMS034 series', cap: '7.5 – 30 TR', feats: ['Floor or ceiling mounted', 'Optional discharge plenum or return grille', '230V, 380V or 460V'] },
    { brand: 'Carrier', name: 'Hydronic Hi-Wall Fan Coils', model: '40HP09-1, 40HP14-1, 40HP18-1', cap: '0.75 – 1.5 TR', feats: ['Chilled water', 'High wall'] },
    { brand: 'Carrier', name: 'Hydronic Floor-Mounted Fan Coils', model: '42BHC, 42SLM, 40HTC series', cap: '3 – 10 TR', feats: ['Chilled water', 'Floor standing', 'Manual controls (40HTC)'] },
    { brand: 'Carrier', name: 'Hydronic Ceiling Ducted, Hi-Static', model: '40LM series', cap: '4.0 HP – 10 TR', feats: ['Chilled water', 'High static ducted', 'Digital controls'] },
    { brand: 'Carrier', name: 'Hydronic Underceiling Fan Coils', model: '42FLWCAR03 / 05', cap: '3 – 5 TR', feats: ['Chilled water', 'Ceiling suspended'] }
  ]);

  // Category capacity ranges widened by the new lineups.
  PRODUCTS.forEach(function (p) {
    if (p.slug === 'window') { p.cap = '0.5 – 2.5 HP'; p.capAlt = 'Portable 1.0 – 1.5 HP'; }
    if (p.slug === 'wall') p.cap = '1.0 – 3.0 HP';
    if (p.slug === 'floor') p.capAlt = 'Up to 10 TR';
    if (p.slug === 'cassette') p.capAlt = 'Up to 5 TR';
    if (p.slug === 'concealed') p.capAlt = 'Ducted up to 30 TR';
  });

  PRODUCTS.splice(4, 0, { slug: 'suspended', name: 'Ceiling Suspended', short: 'Ceiling Suspended', seg: ['Commercial'], cap: '4.0 – 6.0 HP', capAlt: 'Up to 5 TR', rate: '₱2,500',
    tagline: 'Mounted under the ceiling, no ceiling cut-out needed.',
    intro: 'The indoor unit hangs flush against the ceiling and throws air across the room. A good fit where there is no ceiling space for a cassette or ducts.',
    good: ['Shops, restaurants and showrooms', 'Offices with low or solid ceilings', 'Retrofits where the ceiling cannot be opened'],
    series: [
      { brand: 'Carrier', name: 'Optima Underceiling', model: '53FLG004-ASC04H, 53FLGASC006, 53CUV036308-3, 53CUV055308-3', cap: '4.0 – 6.0 HP', feats: ['Underceiling', 'R32 refrigerant (53CUV)'] },
      { brand: 'Everest', name: 'Ceiling Mounted Inverter', model: 'ETIV36XCFR3, ETIV601XCFR3, ETIV603XCFR3', cap: '3.0 – 5.0 TR', feats: ['Inverter', '1-phase or 3-phase (5 TR)'] },
      { brand: 'Everest', name: 'Ceiling Mounted, Non-Inverter', model: 'ET36XCF/M, ETR2CF60U', cap: '3.0 – 5.0 TR', feats: ['Non-inverter', '1-phase (3 TR) or 3-phase (5 TR)'] }
    ] });

  PRODUCTS.push({ slug: 'aircare', name: 'Air Care', short: 'Air Care', seg: ['Residential', 'Commercial'], cap: 'Purifiers to air curtains', rate: 'Quote',
    tagline: 'Purifiers, dehumidifiers, air coolers and air curtains.',
    intro: 'Equipment that works alongside your aircon: cleaner air, lower humidity, spot cooling and doorways that keep cool air in.',
    good: ['Homes and offices that want cleaner air', 'Humid rooms and storage areas', 'Shop entrances, clinics and isolation rooms'],
    series: [
      { brand: 'Carrier', name: 'Air Purifier', model: 'CAUN026LC1, CAUN051LC1', cap: 'CADR 260 – 510', capNote: 'm³/h', feats: ['Clean air delivery rate 260 or 510 m³/h'] },
      { brand: 'Carrier', name: 'OptiClean Negative Air Machine', model: '40NAMCAR50CEES0DN, 40NAMCAR-1KEES0DN', cap: '500 – 1,000 CFM', feats: ['Negative pressure air cleaning', 'With or without duct accessory'] },
      { brand: 'Carrier', name: 'Dehumidifier', model: 'DX-12L, DX-30L', cap: '12 – 30 L', feats: ['LED display (30 L)', 'R32 refrigerant (30 L)'] },
      { brand: 'Everest', name: 'Air Purifier, 5-Stage', model: 'ETAPR668U', cap: '5 stage', feats: ['UV light ionizer', 'Photo catalyst, activated carbon and HEPA filters', 'Remote control and timer', 'Air quality indicator'] },
      { brand: 'Everest', name: 'Air Purifier, 6-Stage', model: 'ETAPRC03U', cap: '6 stage', feats: ['UV light ionizer', 'Pre-filter, photo catalyst, activated carbon and HEPA filters', 'Touch panel, remote and timer', '3 fan speeds'] },
      { brand: 'Everest', name: 'Air Cooler', model: 'ETAC500M, ETAC850M, ETAC1200TW', cap: '40 – 80 L', capNote: 'water tank', feats: ['Ice pack chamber (Tornado series)', 'Wide-angle air supply', 'Wheeled base', 'Dual fan (ETAC1200TW)'] },
      { brand: 'Everest', name: 'Air Curtain', model: 'ETCU3509DM-R, ETCU3512DM-R', cap: '900 – 1,200 mm', feats: ['For doorways and shop entrances', '220V / 1-phase'] }
    ] });

  // HD product photos supplied for these categories (upscaled for sharp display).
  IMG.hd_suspended = 'assets/img/hd-suspended.webp';
  IMG.hd_concealed = 'assets/img/hd-concealed.webp';
  IMG.hd_aircare = 'assets/img/hd-aircare.webp';
  PRODUCTS.forEach(function (p) {
    if (p.slug === 'suspended') { p.photo = 'hd_suspended'; p.shot = true; p.photoAlt = 'Ceiling suspended indoor unit'; }
    if (p.slug === 'concealed') { p.photo = 'hd_concealed'; p.shot = true; p.photoAlt = 'Ceiling-mounted indoor unit with a slim linear grille'; delete p.credit; }
    if (p.slug === 'aircare') { p.photo = 'hd_aircare'; p.shot = true; p.photoAlt = 'Everest air cooler on wheels'; }
  });

  var prodListView = document.getElementById('products-view');
  var prodDetailView = document.getElementById('product-view');
  function ucard(p) {
    return '<a class="ucard" href="#product-' + p.slug + '"><div class="ucard-art' + (p.photo ? ' has-photo' : '') + (p.shot ? ' shot' : '') + '">' + (p.photo ? '<img src="' + IMG[p.photo] + '" alt="' + esc(p.photoAlt) + '" loading="lazy"' + (p.photoPos ? ' style="object-position:' + p.photoPos + '"' : '') + '>' : ART[p.slug]) + '<span class="label">' + esc(p.seg.join(' · ')) + '</span></div>' +
      '<div class="ucard-body"><h3>' + esc(p.name) + '</h3><p>' + esc(p.tagline) + '</p>' +
      '<div class="ucard-meta"><strong>' + esc(p.cap) + '</strong><span>Details →</span></div></div></a>';
  }
  var uh = document.getElementById('unitsHome'); if (uh) uh.innerHTML = PRODUCTS.map(ucard).join('');

  function renderProducts(filter) {
    filter = filter || 'All';
    var items = PRODUCTS.filter(function (p) { return filter === 'All' || p.seg.indexOf(filter) > -1; });
    prodListView.innerHTML =
      '<section class="page-hero on-red"><div class="wrap">' +
        '<nav class="crumbs" aria-label="Breadcrumb"><a href="#home">Home</a><span aria-hidden="true">/</span><span>Products</span></nav>' +
        '<span class="eyebrow">Supply and installation</span><h1>Products</h1>' +
        '<p class="lead">Seven unit types plus air care, from window units for a single room to chilled water plants for whole buildings. We supply, install and maintain every one.</p>' +
        '<div class="pstats"><div><strong>8</strong><span>product types</span></div><div><strong>0.5 HP</strong><span>to 3,000 TR</span></div><div><strong>R32</strong><span>on LG, Koppel and Carrier inverter lines</span></div></div>' +
      '</div></section>' +
      '<section class="section"><div class="wrap">' +
        '<div class="filters" role="group" aria-label="Filter products">' + ['All', 'Residential', 'Small business', 'Commercial', 'Industrial'].map(function (f) {
          return '<button type="button" class="chip" data-filter="' + f + '" aria-pressed="' + (f === filter) + '">' + f + '</button>'; }).join('') + '</div>' +
        '<div class="ugrid">' + items.map(ucard).join('') + '</div>' +
        '<p class="note-line">Lineups shown are from <b>LG</b>, <b>Koppel</b>, <b>Carrier</b>, <b>Condura</b> and <b>Everest</b>. We also supply Midea. Ask us for current models.</p>' + '<p class="note-line" style="font-size:12px;color:var(--ink-muted)">Photos are for illustration only.</p>' +
        '<div class="mini-cta"><div><h2>Not sure which unit fits?</h2><p>Book a site assessment and we will size it for your space.</p></div><a class="btn btn-primary btn-lg" href="#contact">Request a site assessment <span class="arrow" aria-hidden="true">→</span></a></div>' +
      '</div></section>';
    prodListView.querySelectorAll('.chip').forEach(function (c) {
      c.addEventListener('click', function () { renderProducts(c.getAttribute('data-filter')); var b = prodListView.querySelector('.chip[aria-pressed="true"]'); if (b) b.focus(); });
    });
  }

  function renderProduct(p) {
    var i = PRODUCTS.indexOf(p), prev = PRODUCTS[(i - 1 + PRODUCTS.length) % PRODUCTS.length], next = PRODUCTS[(i + 1) % PRODUCTS.length];
    var tick = '<svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true" style="margin-top:5px"><path class="check" d="M2 7.5l3 3 7-7" fill="none" stroke-width="2"/></svg>';
    prodDetailView.innerHTML =
      '<section class="page-hero on-red"><div class="wrap pd-hero-grid"><div style="display:grid;gap:20px;min-width:0">' +
        '<nav class="crumbs" aria-label="Breadcrumb"><a href="#home">Home</a><span aria-hidden="true">/</span><a href="#products">Products</a><span aria-hidden="true">/</span><span>' + esc(p.short) + '</span></nav>' +
        '<div class="chips">' + p.seg.map(function (s) { return '<span class="label">' + esc(s) + '</span>'; }).join('') + '</div>' +
        '<h1>' + esc(p.name) + '</h1><p class="lead">' + esc(p.intro) + '</p>' +
        '<div class="pstats"><div><strong>' + esc(p.cap) + '</strong><span>' + (p.capAlt ? esc(p.capAlt) : 'capacity range') + '</span></div><div><strong>' + p.series.length + '</strong><span>series available</span></div></div>' +
      '</div><div class="pd-hero-art' + (p.shot ? ' shot' : '') + '">' + (p.photo ? '<img src="' + IMG[p.photo] + '" alt="' + esc(p.photoAlt) + '"' + (p.photoPos ? ' style="object-position:' + p.photoPos + '"' : '') + '>' : ART[p.slug]) + '</div></div></section>' +
      '<section class="section"><div class="wrap"><div class="pd-grid"><div style="min-width:0">' +
        '<div class="sec-head" style="margin-bottom:28px"><span class="eyebrow">Available series</span><h2>Lineup</h2></div>' +
        '<div class="series">' + p.series.map(function (s) {
          return '<article class="srow"><div><span class="brand' + (s.brand === 'LG' ? ' lg' : '') + '">' + esc(s.brand) + '</span><h3>' + esc(s.name) + '</h3>' + (s.model ? '<p class="model">Models ' + esc(s.model) + '</p>' : '') + '</div>' +
            '<ul class="feats">' + s.feats.map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('') + '</ul>' +
            '<div class="cap">' + esc(s.cap) + (s.capNote ? '<small>' + esc(s.capNote) + '</small>' : '') + '</div></article>';
        }).join('') + '</div>' +
        '<p class="note-line">Midea units are also available. Ask us for current models and availability.</p>' + (p.credit ? '<p class="note-line" style="font-size:12px;color:var(--ink-muted)">' + esc(p.credit) + '</p>' : '') +
      '</div><aside class="facts" aria-label="Product summary"><dl>' +
        '<div><dt>Best for</dt><dd><ul class="goodfor">' + p.good.map(function (g) { return '<li>' + tick + '<span>' + esc(g) + '</span></li>'; }).join('') + '</ul></dd></div>' +
        '<div><dt>Capacity</dt><dd>' + esc(p.cap) + (p.capAlt ? '<br>' + esc(p.capAlt) : '') + '</dd></div>' +
        '<div><dt>General cleaning</dt><dd>' + (p.rate === 'Quote' ? 'Maintenance quoted per project' : esc(p.rate) + ' per unit') + '</dd></div>' +
        '<div><dt>We handle</dt><dd>Supply, installation, cleaning and PMS</dd></div>' +
      '</dl><a class="btn btn-primary" href="#contact" data-prod="' + esc(p.short) + '">Request a quote</a><a class="btn btn-secondary" href="#products">All products</a></aside></div>' +
      '<nav class="pnav" aria-label="More products"><a href="#product-' + prev.slug + '"><span class="label">← Previous</span><strong>' + esc(prev.short) + '</strong></a><a href="#product-' + next.slug + '"><span class="label">Next →</span><strong>' + esc(next.short) + '</strong></a></nav>' +
      '</div></section>';
    var qb = prodDetailView.querySelector('[data-prod]');
    if (qb) qb.addEventListener('click', function () { var sel = document.getElementById('f-service'); var msg = document.getElementById('f-msg'); if (sel) sel.value = 'Buy a new unit'; if (msg && !msg.value) msg.value = 'Interested in: ' + p.name; });
  }

  var homeView = document.getElementById('home');
  var listView = document.getElementById('projects-view');
  var detailView = document.getElementById('project-view');
  function esc(t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function setActive(href) { links.forEach(function (l) { l.classList.toggle('active', l.getAttribute('href') === href); }); }

  function renderList(filter) {
    filter = filter || 'All';
    var items = PROJECTS.filter(function (p) { return filter === 'All' || p.type === filter || p.also === filter; });
    listView.innerHTML =
      '<section class="page-hero on-red"><div class="wrap">' +
        '<nav class="crumbs" aria-label="Breadcrumb"><a href="#home">Home</a><span aria-hidden="true">/</span><span>Projects</span></nav>' +
        '<span class="eyebrow">Our work</span><h1>Projects</h1>' +
        '<p class="lead">Maintenance contracts, installations and full supply-and-install jobs for offices, buildings and businesses.</p>' +
        '<div class="pstats"><div><strong>4</strong><span>featured projects</span></div><div><strong>166</strong><span>units on PMS contracts</span></div><div><strong>3</strong><span>service types delivered</span></div></div>' +
      '</div></section>' +
      '<section class="section"><div class="wrap">' +
        '<div class="filters" role="group" aria-label="Filter projects">' + ['All', 'Maintenance', 'Installation'].map(function (f) {
          return '<button type="button" class="chip" data-filter="' + f + '" aria-pressed="' + (f === filter) + '">' + f + '</button>'; }).join('') + '</div>' +
        '<div class="pgrid">' + items.map(function (p) {
          return '<a class="pcard" href="#project-' + p.slug + '">' +
            '<div class="pcard-media"><img src="' + IMG[p.photos[0][0]] + '" alt="' + esc(p.photos[0][1]) + '" loading="lazy"><span class="label pcard-tag">' + esc(p.tag || p.type) + '</span></div>' +
            '<div class="pcard-body"><span class="label" style="color:var(--ink-2)">' + esc(p.client) + '</span><h2>' + esc(p.headline) + '</h2><p>' + esc(p.summary) + '</p>' +
            '<div class="pcard-foot"><strong>' + esc(p.units) + ' <small style="font:500 13px var(--font-sans);color:var(--ink-2)">' + esc(p.unitsLabel) + (p.installs ? ' + 4 × 5TR installed' : '') + '</small></strong><span>View project →</span></div></div></a>';
        }).join('') + '</div>' +
        '<div class="mini-cta"><div><h2>Have a building or office that needs cooling?</h2><p>We start with a site assessment, then quote.</p></div><a class="btn btn-primary btn-lg" href="#contact">Request a site assessment <span class="arrow" aria-hidden="true">→</span></a></div>' +
      '</div></section>';
    listView.querySelectorAll('.chip').forEach(function (c) {
      c.addEventListener('click', function () { renderList(c.getAttribute('data-filter')); var g = listView.querySelector('.filters'); if (g) g.querySelector('[aria-pressed="true"]').focus(); });
    });
  }

  function renderDetail(p) {
    setTimeout(function () { detailView.querySelectorAll('.zoom').forEach(function (b) { b.addEventListener('click', function () { lbOpen(p.photos, +b.getAttribute('data-idx'), b); }); }); }, 0);
    var i = PROJECTS.indexOf(p), prev = PROJECTS[(i - 1 + PROJECTS.length) % PROJECTS.length], next = PROJECTS[(i + 1) % PROJECTS.length];
    detailView.innerHTML =
      '<section class="page-hero on-red"><div class="wrap">' +
        '<nav class="crumbs" aria-label="Breadcrumb"><a href="#home">Home</a><span aria-hidden="true">/</span><a href="#projects">Projects</a><span aria-hidden="true">/</span><span>' + esc(p.short) + '</span></nav>' +
        '<span class="eyebrow">' + esc(p.client) + '</span><h1>' + esc(p.headline) + '</h1><p class="lead">' + esc(p.summary) + '</p>' +
        '<div class="pstats"><div><strong>' + esc(p.units) + '</strong><span>' + esc(p.unitsLabel) + '</span></div>' + (p.installs ? '<div><strong>4</strong><span>5TR units installed</span></div>' : '<div><strong>' + esc(p.type) + '</strong><span>project type</span></div>') + '</div>' +
      '</div></section>' +
      '<section class="section"><div class="wrap"><div class="pd-grid"><div>' +
        '<div class="gallery">' + p.photos.map(function (ph, k) { return '<figure><button type="button" class="zoom" data-idx="' + k + '" aria-label="View larger: ' + esc(ph[1]) + '"><img src="' + IMG[ph[0]] + '" alt="' + esc(ph[1]) + '"></button><figcaption>' + esc(ph[1]) + '</figcaption></figure>'; }).join('') + '</div>' +
        '<div class="pd-body"><span class="eyebrow">The work</span><h2>What we did</h2><p>' + esc(p.body) + '</p>' +
        '<ol class="scope">' + p.scope.map(function (t, k) { return '<li><b>' + (k < 9 ? '0' : '') + (k + 1) + '</b><span>' + esc(t) + '</span></li>'; }).join('') + '</ol></div>' +
      '</div><aside class="facts" aria-label="Project facts"><dl>' +
        '<div><dt>Client</dt><dd>' + esc(p.client) + '</dd></div>' +
        '<div><dt>Service</dt><dd>' + esc(p.service) + '</dd></div>' +
        '<div><dt>Scope</dt><dd>' + esc(p.units) + ' · ' + esc(p.unitsLabel) + '</dd></div>' +
        (p.installs ? '<div><dt>Installed</dt><dd>' + p.installs.map(function (x) { return esc(x[0]) + ' · ' + esc(x[1]); }).join('<br>') + '</dd></div>' : '') +
        '<div><dt>Delivered by</dt><dd>AP Coolcare Services, TESDA-certified team</dd></div>' +
      '</dl><a class="btn btn-primary" href="#contact">Request a similar project</a><a class="btn btn-secondary" href="#projects">All projects</a></aside></div>' +
      '<nav class="pnav" aria-label="More projects"><a href="#project-' + prev.slug + '"><span class="label">← Previous</span><strong>' + esc(prev.short) + '</strong></a><a href="#project-' + next.slug + '"><span class="label">Next →</span><strong>' + esc(next.short) + '</strong></a></nav>' +
      '</div></section>';
  }

  var lb = null, lbList = [], lbIdx = 0, lbReturn = null;
  function lbRender() { lb.querySelector('img').src = IMG[lbList[lbIdx][0]]; lb.querySelector('img').alt = lbList[lbIdx][1]; lb.querySelector('.lb-cap').textContent = lbList[lbIdx][1] + '  ·  ' + (lbIdx + 1) + ' / ' + lbList.length; }
  function lbOpen(list, i, from) {
    if (!lb) {
      lb = document.createElement('div'); lb.className = 'lightbox'; lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true'); lb.setAttribute('aria-label', 'Photo viewer');
      lb.innerHTML = '<button type="button" class="lb-close" aria-label="Close">×</button><button type="button" class="lb-nav lb-prev" aria-label="Previous photo">←</button><figure><img alt=""><figcaption class="lb-cap"></figcaption></figure><button type="button" class="lb-nav lb-next" aria-label="Next photo">→</button>';
      document.body.appendChild(lb);
      lb.addEventListener('click', function (e) { if (e.target === lb || e.target.classList.contains('lb-close')) lbClose(); });
      lb.querySelector('.lb-prev').addEventListener('click', function () { lbIdx = (lbIdx - 1 + lbList.length) % lbList.length; lbRender(); });
      lb.querySelector('.lb-next').addEventListener('click', function () { lbIdx = (lbIdx + 1) % lbList.length; lbRender(); });
      document.addEventListener('keydown', function (e) { if (!lb || lb.hidden) return; if (e.key === 'Escape') lbClose(); if (e.key === 'ArrowLeft') lb.querySelector('.lb-prev').click(); if (e.key === 'ArrowRight') lb.querySelector('.lb-next').click(); });
    }
    lbList = list; lbIdx = i; lbReturn = from; lbRender(); lb.hidden = false; document.body.style.overflow = 'hidden'; lb.querySelector('.lb-close').focus();
  }
  function lbClose() { lb.hidden = true; document.body.style.overflow = ''; if (lbReturn) lbReturn.focus(); }

  function show(view) {
    [homeView, listView, detailView, prodListView, prodDetailView].forEach(function (v) { v.hidden = v !== view; });
  }
  function route(forced) {
    var h = typeof forced === 'string' ? forced : (location.hash || '').slice(1);
    if (h === 'products') { renderProducts(); show(prodListView); setActive('#products'); window.scrollTo(0, 0); document.title = 'Products · AP Coolcare Services'; return; }
    if (h.indexOf('product-') === 0) {
      var pr = PRODUCTS.filter(function (x) { return 'product-' + x.slug === h; })[0];
      if (pr) { renderProduct(pr); show(prodDetailView); setActive('#products'); window.scrollTo(0, 0); document.title = pr.short + ' · AP Coolcare Services'; return; }
    }
    if (h === 'projects') { renderList(); show(listView); setActive('#projects'); window.scrollTo(0, 0); document.title = 'Projects · AP Coolcare Services'; return; }
    if (h.indexOf('project-') === 0) {
      var p = PROJECTS.filter(function (x) { return 'project-' + x.slug === h; })[0];
      if (p) { renderDetail(p); show(detailView); setActive('#projects'); window.scrollTo(0, 0); document.title = p.short + ' · AP Coolcare Services'; return; }
    }
    var wasHidden = homeView.hidden;
    show(homeView); document.title = 'AP Coolcare Services';
    if (wasHidden || typeof forced === 'string') {
      var t = h && document.getElementById(h);
      if (t && h !== 'home') { requestAnimationFrame(function () { t.scrollIntoView(); }); } else { window.scrollTo(0, 0); }
    }
  }
  window.addEventListener('hashchange', function () { route(); });
  // Handle in-page links directly so Products, Projects and section links work
  // even in viewers that block or ignore hash navigation.
  document.addEventListener('click', function (e) {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    var a = e.target.closest && e.target.closest('a[href^="#"]');
    if (!a) return;
    var h = a.getAttribute('href').slice(1);
    e.preventDefault();
    if (h === 'top') { window.scrollTo(0, 0); return; }
    try { history.replaceState(null, '', '#' + h); } catch (err) {}
    route(h || 'home');
  });
  route();

  // Pricing buttons preselect the service
  var sel = document.getElementById('f-service');
  document.querySelectorAll('[data-service]').forEach(function (b) {
    b.addEventListener('click', function () { sel.value = b.getAttribute('data-service'); });
  });

  // Copy buttons
  document.querySelectorAll('.copy-btn').forEach(function (b) {
    b.addEventListener('click', function () {
      var el = document.getElementById(b.getAttribute('data-copy'));
      var text = el.textContent;
      function done() { b.textContent = 'Copied'; setTimeout(function () { b.textContent = 'Copy'; }, 1600); }
      function fallback() { var r = document.createRange(); r.selectNodeContents(el); var s = window.getSelection(); s.removeAllRanges(); s.addRange(r); b.textContent = 'Selected'; setTimeout(function () { b.textContent = 'Copy'; }, 1600); }
      try { navigator.clipboard.writeText(text).then(done, fallback); } catch (err) { fallback(); }
    });
  });

  // Booking form (preview: shows a summary; on WordPress connect it to your form plugin)
  var form = document.getElementById('bookForm');
  var doneBox = document.getElementById('formDone');
  function setErr(id, msg) { var e = document.getElementById('e-' + id); e.textContent = msg; e.parentElement.classList.toggle('invalid', !!msg); }
  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    var ok = true;
    if (!sel.value) { setErr('service', 'Choose the service you need.'); ok = false; } else setErr('service', '');
    var name = document.getElementById('f-name').value.trim();
    if (!name) { setErr('name', 'Enter your name so we know who to ask for.'); ok = false; } else setErr('name', '');
    var phone = document.getElementById('f-phone').value.replace(/[^0-9+]/g, '');
    if (phone.length < 10) { setErr('phone', 'Enter a mobile number with at least 10 digits, like 0917 322 0747.'); ok = false; } else setErr('phone', '');
    if (!ok) { var first = form.querySelector('.invalid input, .invalid select'); if (first) first.focus(); return; }
    var ptype = form.querySelector('input[name="ptype"]:checked').value;
    var units = document.getElementById('f-units').value || '1';
    var date = document.getElementById('f-date').value;
    doneBox.hidden = false;
    doneBox.innerHTML = '';
    var h = document.createElement('strong'); h.textContent = 'Request ready: ' + sel.value; doneBox.appendChild(h);
    var p = document.createElement('span'); p.textContent = name + ' · ' + ptype + ' · ' + units + (units === '1' ? ' unit' : ' units') + (date ? ' · ' + date : ''); doneBox.appendChild(p);
    var n = document.createElement('span'); n.style.color = 'var(--ink-2)'; n.textContent = 'This page is a preview, so the form is not connected yet. On the live site it will send to apcoolcare.support@gmail.com. For now, call 0917 322 0747 to book.'; doneBox.appendChild(n);
  });
})();
